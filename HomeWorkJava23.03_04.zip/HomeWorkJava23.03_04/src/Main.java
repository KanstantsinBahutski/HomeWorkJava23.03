import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int x1 = rnd.nextInt();
        System.out.println("Первое число: " + x1);
        int x2 = rnd.nextInt();
        System.out.println("Второе число: " + x2);
        int x3 = rnd.nextInt();
        System.out.println("Третье число: " + x3);
        if (x1 >= x2 && x1 >= x3){
            System.out.println("Большее число: " + x1);
        }
        if (x2 >= x1 && x2 >= x3){
            System.out.println("Большее число: " + x2);
        }
        if (x3 >= x1 && x3 >= x2){
            System.out.println("Большее число: " + x3);
        }
    }
}