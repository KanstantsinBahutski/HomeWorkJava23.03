import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите число: ");
        double number = scn.nextDouble();
        if (number > 0 && number % 2 != 0) {
            System.out.println("Умножение на 2: " + number * 2);
        }
        if ((number % 10 == 5 || number % 10 == 0) && number > 0) {
            System.out.println("Прибавляем 5 :" + (number + 5));
        }
        if (number < 0) {
            System.out.println("Модуль числа делим на 3: " + Math.abs(number) / 3);
        }


    }
}