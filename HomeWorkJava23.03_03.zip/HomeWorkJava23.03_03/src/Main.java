import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите первое число: ");
        int x1 = scn.nextInt();
        System.out.println("Введите второе число: ");
        int x2 = scn.nextInt();
        if (x1 != x2){
            System.out.println("Сумма неравных чисел: " + (x1 + x2));
        }
        else {
            System.out.println("Произведение равных чисел: " + x1 * x2);
        }
    }
}