import java.util.Scanner;

//if (text.charAt(0) == 0 || text.charAt(0) == 1 || text.charAt(0) == 2 || text.charAt(0) == 3 || text.charAt(0) == 4 ||
//                text.charAt(0) == 5 || text.charAt(0) == 6 || text.charAt(0) == 7 || text.charAt(0) == 8 || text.charAt(0) == 9) {
//            System.out.println(text.charAt(0));
//        }

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите строку :");
        String text = scn.next();
        if (text.startsWith("_") || text.startsWith("-")) {
            System.out.println(text.substring(1));
        }
        if (text.charAt(0) == '0' || text.charAt(0) == '1' || text.charAt(0) == '2' || text.charAt(0) == '3' || text.charAt(0) == '4' ||
                text.charAt(0) == '5' || text.charAt(0) == '6' || text.charAt(0) == '7' || text.charAt(0) == '8' || text.charAt(0) == '9') {
            System.out.println(text.charAt(0));
        }
    }
}